/*
 * Copyright (C) 2026 Mitch Trachtenberg — GPL v3
 */
package gov.election.ballot.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private final LockInterceptor lockInterceptor;

    public WebMvcConfig(LockInterceptor lockInterceptor) {
        this.lockInterceptor = lockInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(lockInterceptor);
    }
}
