/*
 * Copyright (C) 2026 Mitch Trachtenberg — GPL v3
 */
package gov.election.ballot.config;

import gov.election.ballot.service.LockService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.FlashMap;
import org.springframework.web.servlet.support.RequestContextUtils;

/**
 * Blocks all POST and DELETE requests (except lock/unlock and user management)
 * when the system is locked. This enforces the lock server-side so it cannot
 * be bypassed by submitting forms directly.
 */
@Component
public class LockInterceptor implements HandlerInterceptor {

    private final LockService lockService;

    public LockInterceptor(LockService lockService) {
        this.lockService = lockService;
    }

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             Object handler) throws Exception {

        String method = request.getMethod();
        if (!"POST".equals(method) && !"DELETE".equals(method)) return true;

        String path = request.getRequestURI();

        // Always allow: lock/unlock, login/logout, password change, user management,
        // CSRF token endpoint, Spring Security internals
        if (path.startsWith("/admin/lock")   ||
            path.startsWith("/admin/unlock") ||
            path.startsWith("/admin/users")  ||
            path.startsWith("/login")        ||
            path.startsWith("/logout")       ||
            path.startsWith("/account/")     ||
            path.startsWith("/api/test/")    ||   // test API exempt
            path.startsWith("/setup/seed")   ) {  // seed data exempt
            return true;
        }

        if (lockService.isLocked()) {
            // Store error in flash scope and redirect back
            var flashMap = new FlashMap();
            flashMap.put("error",
                "⛔ System is locked. Unlock it before making changes.");
            RequestContextUtils
                .getFlashMapManager(request)
                .saveOutputFlashMap(flashMap, request, response);
            String referer = request.getHeader("Referer");
            response.sendRedirect(referer != null ? referer : "/dashboard");
            return false;
        }

        return true;
    }
}
