/*
 * Copyright (C) 2026 Mitch Trachtenberg — GPL v3
 */
package gov.election.ballot.controller;

import gov.election.ballot.service.LockService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
public class LockController {

    private final LockService lockService;

    public LockController(LockService lockService) {
        this.lockService = lockService;
    }

    @PostMapping("/lock")
    public String lock(@RequestParam(required = false) String reason,
                       Authentication auth,
                       RedirectAttributes ra) {
        lockService.lock(auth.getName(), reason);
        ra.addFlashAttribute("success",
            "System locked by " + auth.getName() + ". Ballot generation is disabled.");
        return "redirect:/dashboard";
    }

    @PostMapping("/unlock")
    public String unlock(@RequestParam(required = false) String reason,
                         Authentication auth,
                         RedirectAttributes ra) {
        lockService.unlock(auth.getName(), reason);
        ra.addFlashAttribute("success",
            "System unlocked by " + auth.getName() + ". Ballot generation is re-enabled.");
        return "redirect:/dashboard";
    }
}
