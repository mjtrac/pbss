/*
 * Copyright (C) 2026 Mitch Trachtenberg — GPL v3
 */
package gov.election.ballot.controller;

import gov.election.ballot.service.LockService;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

/**
 * Adds global model attributes available to every Thymeleaf template.
 * Currently adds systemLocked so layout.html can show the lock banner
 * without each controller needing to inject LockService.
 */
@ControllerAdvice
public class GlobalModelAdvice {

    private final LockService lockService;

    public GlobalModelAdvice(LockService lockService) {
        this.lockService = lockService;
    }

    @ModelAttribute
    public void addLockState(Model model) {
        model.addAttribute("systemLocked", lockService.isLocked());
        model.addAttribute("systemLock",   lockService.getLock());
    }
}
