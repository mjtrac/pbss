/*
 * Copyright (C) 2026 Mitch Trachtenberg — GPL v3
 */
package gov.election.ballot.service;

import gov.election.ballot.model.AuditLog;
import gov.election.ballot.model.SystemLock;
import gov.election.ballot.repository.AuditLogRepository;
import gov.election.ballot.repository.SystemLockRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class LockService {

    private final SystemLockRepository lockRepo;
    private final AuditLogRepository   auditRepo;

    public LockService(SystemLockRepository lockRepo,
                       AuditLogRepository auditRepo) {
        this.lockRepo  = lockRepo;
        this.auditRepo = auditRepo;
    }

    /** Returns the current lock state (creating the row if it doesn't exist). */
    public SystemLock getLock() {
        return lockRepo.findById(1L).orElseGet(() -> {
            SystemLock sl = new SystemLock();
            return lockRepo.save(sl);
        });
    }

    public boolean isLocked() {
        return getLock().isLocked();
    }

    @Transactional
    public void lock(String username, String reason) {
        SystemLock sl = getLock();
        sl.setLocked(true);
        sl.setLockedAt(LocalDateTime.now());
        sl.setLockedBy(username);
        sl.setReason(reason);
        lockRepo.save(sl);
        auditRepo.save(new AuditLog(AuditLog.Action.LOCK, username,
            "System locked. Reason: " + (reason != null ? reason : "(none)")));
    }

    @Transactional
    public void unlock(String username, String reason) {
        SystemLock sl = getLock();
        sl.setLocked(false);
        sl.setLockedAt(null);
        sl.setLockedBy(null);
        sl.setReason(null);
        lockRepo.save(sl);
        auditRepo.save(new AuditLog(AuditLog.Action.UNLOCK, username,
            "System unlocked. Reason: " + (reason != null ? reason : "(none)")));
    }
}
