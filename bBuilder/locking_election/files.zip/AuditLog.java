/*
 * Copyright (C) 2026 Mitch Trachtenberg — GPL v3
 */
package gov.election.ballot.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Audit log entry for lock/unlock events.
 */
@Entity
@Table(name = "audit_log")
public class AuditLog {

    public enum Action { LOCK, UNLOCK }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Action action;

    @Column(nullable = false)
    private String performedBy;

    @Column(nullable = false)
    private LocalDateTime performedAt;

    @Column(length = 500)
    private String notes;

    public AuditLog() {}

    public AuditLog(Action action, String performedBy, String notes) {
        this.action      = action;
        this.performedBy = performedBy;
        this.performedAt = LocalDateTime.now();
        this.notes       = notes;
    }

    public Long getId()              { return id; }
    public Action getAction()        { return action; }
    public String getPerformedBy()   { return performedBy; }
    public LocalDateTime getPerformedAt() { return performedAt; }
    public String getNotes()         { return notes; }
}
