/*
 * Copyright (C) 2026 Mitch Trachtenberg — GPL v3
 */
package gov.election.ballot.repository;

import gov.election.ballot.model.SystemLock;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SystemLockRepository extends JpaRepository<SystemLock, Long> {}
