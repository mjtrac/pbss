/*
 * Copyright (C) 2026 Mitch Trachtenberg — GPL v3
 */
package gov.election.ballot.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Single-row table representing the system lock state.
 * Always exactly one row with id=1.
 */
@Entity
@Table(name = "system_lock")
public class SystemLock {

    @Id
    private Long id = 1L;

    private boolean locked = false;

    private LocalDateTime lockedAt;

    private String lockedBy;

    @Column(length = 500)
    private String reason;

    public Long getId()                     { return id; }
    public boolean isLocked()               { return locked; }
    public void setLocked(boolean locked)   { this.locked = locked; }
    public LocalDateTime getLockedAt()      { return lockedAt; }
    public void setLockedAt(LocalDateTime t){ this.lockedAt = t; }
    public String getLockedBy()             { return lockedBy; }
    public void setLockedBy(String u)       { this.lockedBy = u; }
    public String getReason()               { return reason; }
    public void setReason(String r)         { this.reason = r; }
}
